package com.example.mqspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MqspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
